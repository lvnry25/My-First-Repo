let book = {
    title: "The Hobbit",
    author: "J.R.R. Tolkien",
    pages: 310,
    isRead: false
};

console.log(book.title);
console.log(book["author"]); 
book.isRead = true;
book.genre = "Fantasy";

console.log(book);

let movies = [
    { title: "Inception", director: "Christopher Nolan", year: 2010 },
    { title: "Interstellar", director: "Christopher Nolan", year: 2014 },
    { title: "The Matrix", director: "Lana & Lilly Wachowski", year: 1999 }
];

console.log(movies[1].title);
movies.push({ title: "Avatar", director: "James Cameron", year: 2009 });
movies[0].year = 2023;
console.log(movies);

let student = {
    name: "Alan",
    age: 22,
    subjects: ["Math", "Science", "History"]
};

console.log(student.subjects[0]);
student.subjects.push("Computer Science");
console.log(student);

let recipe = {
    name: "Pasta Salad",
    ingredients: [
        { name: "Pasta", quantity: "200g", isVegetarian: true },
        { name: "Olive Oil", quantity: "2 tbsp", isVegetarian: true },
        { name: "Chicken", quantity: "150g", isVegetarian: false }
    ]
};

recipe.ingredients.push({ name: "Parmesan Cheese", quantity: "50g", isVegetarian: true });

console.log(recipe.ingredients[1].name);

console.log(recipe);
