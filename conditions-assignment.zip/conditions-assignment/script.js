// Task 1: Grading System
let score = 85; // Change this value to test different scores
let grade;

if (score >= 90 && score <= 100) {
    grade = "A";
} else if (score >= 80 && score <= 89) {
    grade = "B";
} else if (score >= 70 && score <= 79) {
    grade = "C";
} else if (score >= 60 && score <= 69) {
    grade = "D";
} else {
    grade = "F";
}

console.log(`Score: ${score}, Grade: ${grade}`);


// Task 2: Weather Advisor
let temperature = 28; // Change this value to test different temperatures

if (temperature < 0) {
    console.log("It's freezing outside! Bundle up!");
} else if (temperature >= 0 && temperature <= 15) {
    console.log("It's cold outside. Wear a jacket.");
} else if (temperature >= 16 && temperature <= 30) {
    console.log("The weather is nice. Enjoy your day!");
} else {
    console.log("It's hot outside. Stay hydrated!");
}


// Task 3: Eligibility Checker
let age = 17; // Change this value to test different ages

if (age < 13) {
    console.log("You are too young for this activity.");
} else if (age >= 13 && age <= 17) {
    console.log("You need parental permission.");
} else {
    console.log("You are eligible for this activity.");
}


// Task 4: Ticket Price Calculator
let isMember = true; // Change this to false to test non-members
let ticketPrice;

if (age < 12) {
    ticketPrice = "$0 (Free)";
} else if (age >= 12 && isMember) {
    ticketPrice = "$10";
} else {
    ticketPrice = "$15";
}

console.log(`Age: ${age}, Membership: ${isMember}, Ticket Price: ${ticketPrice}`);


// Task 5: Challenge Task - Leap Year Checker
function isLeapYear(year) {
    if ((year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0)) {
        return true;
    }
    return false;
}

// Test the function with different years
console.log(`2024 is a leap year: ${isLeapYear(2024)}`);
console.log(`2023 is a leap year: ${isLeapYear(2023)}`);
console.log(`2000 is a leap year: ${isLeapYear(2000)}`);
console.log(`1900 is a leap year: ${isLeapYear(1900)}`);
